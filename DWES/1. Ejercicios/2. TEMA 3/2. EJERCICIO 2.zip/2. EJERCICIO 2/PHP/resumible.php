<?php
interface Resumible
{

    public function muestraResumen();
}
?>