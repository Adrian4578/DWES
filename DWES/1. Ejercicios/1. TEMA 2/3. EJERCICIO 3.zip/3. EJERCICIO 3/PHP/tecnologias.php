<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tecnologias</title>
</head>

<body>
    <?php
    //código con instrucciones php
    require("cabecera.inc.php");
    ?>
    <nav>
        <ol>
            <li>Java</li>
            <li>Android</li>
            <li>Kotlin</li>
            <li>C#</li>
            <li>CSS</li>
        </ol>
        <br>

        <a href="./principal.php">Principal</a>
    </nav>
</body>
<?php
    //código con instrucciones php
    require("footer.inc.php");
    ?>
</html>