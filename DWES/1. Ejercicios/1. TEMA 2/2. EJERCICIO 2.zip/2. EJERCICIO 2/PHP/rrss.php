<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RRSS</title>
</head>

<body>
    <?php
    //código con instrucciones php
    require("cabecera.inc.php");
    ?>
    <nav>
        <img src="../IMGS/fACEBOOK.jfif" alt="">
        <a href="https://Facebook.com/">Mi Facebook</a>
        <br>
        <img src="../IMGS/twitter.jfif" alt="">
        <a href="https://twitter.com/">Mi Twitter</a>
        <br>
        <a href="./principal.php">Principal</a>
    </nav>
</body>
<?php
    //código con instrucciones php
    require("footer.inc.php");
    ?>
</html>